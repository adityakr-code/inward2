package com.framework.web;

import com.framework.base.BaseWebTest;
import com.framework.config.ConfigReader;
import com.framework.pages.components.CustomDropdown;
import com.framework.pages.web.DropdownDemoPage;
import com.framework.utils.DropdownComparator;
import com.framework.utils.ExcelReader;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.List;
import java.util.Map;

public class DropdownValidationTest extends BaseWebTest {

    @Test(groups = "web")
    public void validateDropdownValuesAgainstExcel() {
        Map<String, List<String>> expected = ExcelReader.readDropdowns(
                ConfigReader.get("dropdown.excel.path"),
                ConfigReader.get("dropdown.excel.sheet"));

        DropdownDemoPage page = new DropdownDemoPage().open();
        Map<String, CustomDropdown> dropdowns = page.getDropdowns();

        SoftAssert soft = new SoftAssert();   // keep going so ALL dropdowns get checked

        for (Map.Entry<String, List<String>> entry : expected.entrySet()) {
            String name = entry.getKey();
            CustomDropdown dropdown = dropdowns.get(name);

            if (dropdown == null) {
                System.out.println("==================================================");
                System.out.println("Dropdown : " + name + "  ->  NO LOCATOR MAPPED in page class");
                soft.assertTrue(false, "No locator mapped for dropdown '" + name + "'");
                continue;
            }

            List<String> actual = dropdown.getAllOptions();
            DropdownComparator.Result result = DropdownComparator.compare(name, entry.getValue(), actual);
            result.print();

            soft.assertTrue(result.getMissing().isEmpty(),
                    "[" + name + "] values missing on UI: " + result.getMissing());
            soft.assertTrue(result.getExtra().isEmpty(),
                    "[" + name + "] new values on UI not in Excel: " + result.getExtra());
        }

        soft.assertAll();   // reports every failure together at the end
    }
}
