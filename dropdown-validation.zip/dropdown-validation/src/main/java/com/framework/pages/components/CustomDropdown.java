package com.framework.pages.components;

import com.framework.pages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Reusable component for NON-<select> dropdowns (div/ul/li, Angular/React/etc.).
 * Only needs two locators:
 *   trigger - the element you click to open the list
 *   options - ALL option elements of that list
 *
 * Handles scrollable / lazy-loaded lists by scrolling to the last option
 * until no new values appear.
 */
public class CustomDropdown extends BasePage {

    private final By trigger;
    private final By options;

    public CustomDropdown(By trigger, By options) {
        this.trigger = trigger;
        this.options = options;
    }

    public List<String> getAllOptions() {
        open();
        Set<String> values = new LinkedHashSet<>();
        try {
            int previousSize;
            do {
                previousSize = values.size();
                List<WebElement> elements = driver.findElements(options);
                for (WebElement element : elements) {
                    try {
                        String text = readText(element);
                        if (!text.isEmpty()) {
                            values.add(text);
                        }
                    } catch (StaleElementReferenceException ignored) {
                        // list re-rendered while reading; next loop picks it up
                    }
                }
                if (!elements.isEmpty()) {
                    try {
                        scrollIntoView(elements.get(elements.size() - 1));
                    } catch (StaleElementReferenceException ignored) {
                        // ignore, next loop re-reads
                    }
                    pause(300); // give lazy-loaded lists time to append items
                }
            } while (values.size() > previousSize);
        } finally {
            close();
        }
        return new ArrayList<>(values);
    }

    public void select(String visibleText) {
        open();
        for (WebElement element : driver.findElements(options)) {
            if (readText(element).equals(visibleText)) {
                element.click();
                return;
            }
        }
        throw new IllegalArgumentException("Option not found: " + visibleText);
    }

    // ------------------------------------------------------------ internals
    private void open() {
        if (!isOpen()) {
            click(trigger);
        }
        wait.until(d -> isOpen());
    }

    private void close() {
        new Actions(driver).sendKeys(Keys.ESCAPE).perform();
        pause(200);
        if (isOpen()) {
            click(trigger); // ESC not supported by this dropdown: toggle it shut
        }
    }

    private boolean isOpen() {
        for (WebElement element : driver.findElements(options)) {
            try {
                if (element.isDisplayed()) {
                    return true;
                }
            } catch (StaleElementReferenceException ignored) {
                // treat as not visible
            }
        }
        return false;
    }

    private String readText(WebElement element) {
        String text = element.getText();
        if (text == null || text.trim().isEmpty()) {
            text = element.getAttribute("textContent"); // fallback for CSS-truncated text
        }
        return text == null ? "" : text.replaceAll("\\s+", " ").trim();
    }

    private void scrollIntoView(WebElement element) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'end'});", element);
    }

    private void pause(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
