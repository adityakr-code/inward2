package com.framework.pages.web;

import com.framework.config.ConfigReader;
import com.framework.pages.BasePage;
import com.framework.pages.components.CustomDropdown;
import org.openqa.selenium.By;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Demo page that ships with a local HTML file. For your real application create a
 * similar page class: map each Excel column header to its trigger + options locators.
 */
public class DropdownDemoPage extends BasePage {

    public DropdownDemoPage open() {
        String url = new File(ConfigReader.get("demo.page.path")).getAbsoluteFile().toURI().toString();
        driver.get(url);
        return this;
    }

    /** Key MUST match the header text in the Excel sheet. */
    public Map<String, CustomDropdown> getDropdowns() {
        Map<String, CustomDropdown> map = new LinkedHashMap<>();
        map.put("Country", new CustomDropdown(
                By.cssSelector("#dd-country .dd-trigger"),
                By.cssSelector("#dd-country .dd-list li")));
        map.put("Status", new CustomDropdown(
                By.cssSelector("#dd-status .dd-trigger"),
                By.cssSelector("#dd-status .dd-list li")));
        return map;
    }
}
