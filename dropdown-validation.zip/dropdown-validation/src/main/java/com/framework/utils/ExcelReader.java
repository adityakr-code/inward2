package com.framework.utils;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Reads expected dropdown values from Excel.
 *
 * Layout: first row = dropdown names, every cell below = one expected value.
 *
 *   | Country | Status      |
 *   | India   | Open        |
 *   | USA     | In Progress |
 *   | UK      | Closed      |
 */
public final class ExcelReader {

    private ExcelReader() {
    }

    public static Map<String, List<String>> readDropdowns(String filePath, String sheetName) {
        Map<String, List<String>> result = new LinkedHashMap<>();
        DataFormatter formatter = new DataFormatter();

        try (Workbook workbook = WorkbookFactory.create(new File(filePath))) {
            FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
            Sheet sheet = (sheetName == null || sheetName.isEmpty())
                    ? workbook.getSheetAt(0)
                    : workbook.getSheet(sheetName);
            if (sheet == null) {
                throw new IllegalArgumentException("Sheet '" + sheetName + "' not found in " + filePath);
            }

            int firstRow = sheet.getFirstRowNum();
            Row header = sheet.getRow(firstRow);
            if (header == null) {
                return result;
            }

            for (int col = header.getFirstCellNum(); col >= 0 && col < header.getLastCellNum(); col++) {
                String name = cellText(header.getCell(col), formatter, evaluator);
                if (name.isEmpty()) {
                    continue;
                }
                List<String> values = new ArrayList<>();
                for (int r = firstRow + 1; r <= sheet.getLastRowNum(); r++) {
                    Row row = sheet.getRow(r);
                    if (row == null) {
                        continue;
                    }
                    String value = cellText(row.getCell(col), formatter, evaluator);
                    if (!value.isEmpty()) {
                        values.add(value);
                    }
                }
                result.put(name, values);
            }
        } catch (IOException e) {
            throw new IllegalStateException("Unable to read Excel file: " + filePath, e);
        }
        return result;
    }

    private static String cellText(Cell cell, DataFormatter formatter, FormulaEvaluator evaluator) {
        if (cell == null) {
            return "";
        }
        String text = formatter.formatCellValue(cell, evaluator);
        return text == null ? "" : text.replaceAll("\\s+", " ").trim();
    }
}
