package com.framework.utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Compares expected values (Excel) with actual values (UI) for one dropdown.
 *  - missing = in Excel but NOT on the page
 *  - extra   = on the page but NOT in Excel (a newly added value)
 */
public final class DropdownComparator {

    private DropdownComparator() {
    }

    public static Result compare(String name, List<String> expected, List<String> actual) {
        return compare(name, expected, actual, false);
    }

    public static Result compare(String name, List<String> expected, List<String> actual, boolean ignoreCase) {
        Map<String, String> exp = toMap(expected, ignoreCase);
        Map<String, String> act = toMap(actual, ignoreCase);

        List<String> missing = new ArrayList<>();
        for (Map.Entry<String, String> e : exp.entrySet()) {
            if (!act.containsKey(e.getKey())) {
                missing.add(e.getValue());
            }
        }
        List<String> extra = new ArrayList<>();
        for (Map.Entry<String, String> e : act.entrySet()) {
            if (!exp.containsKey(e.getKey())) {
                extra.add(e.getValue());
            }
        }
        return new Result(name, new ArrayList<>(exp.values()), new ArrayList<>(act.values()), missing, extra);
    }

    /** key = normalised text used for comparison, value = original text used for reporting. */
    private static Map<String, String> toMap(List<String> values, boolean ignoreCase) {
        Map<String, String> map = new LinkedHashMap<>();
        for (String v : values) {
            if (v == null) {
                continue;
            }
            String clean = v.replaceAll("\\s+", " ").trim();
            if (clean.isEmpty()) {
                continue;
            }
            map.put(ignoreCase ? clean.toLowerCase() : clean, clean);
        }
        return map;
    }

    public static final class Result {
        private final String name;
        private final List<String> expected;
        private final List<String> actual;
        private final List<String> missing;
        private final List<String> extra;

        Result(String name, List<String> expected, List<String> actual, List<String> missing, List<String> extra) {
            this.name = name;
            this.expected = expected;
            this.actual = actual;
            this.missing = missing;
            this.extra = extra;
        }

        public String getName() {
            return name;
        }

        public List<String> getMissing() {
            return Collections.unmodifiableList(missing);
        }

        public List<String> getExtra() {
            return Collections.unmodifiableList(extra);
        }

        public boolean isMatch() {
            return missing.isEmpty() && extra.isEmpty();
        }

        public void print() {
            System.out.println("==================================================");
            System.out.println("Dropdown : " + name);
            System.out.println("Excel    : " + expected.size() + " values " + expected);
            System.out.println("UI       : " + actual.size() + " values " + actual);
            if (isMatch()) {
                System.out.println("RESULT   : PASS - all values match");
            } else {
                if (!missing.isEmpty()) {
                    System.out.println("MISSING on UI (in Excel, not on page) : " + missing);
                }
                if (!extra.isEmpty()) {
                    System.out.println("NEW on UI (on page, not in Excel)     : " + extra);
                }
            }
        }
    }
}
